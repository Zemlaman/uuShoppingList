const initialItems = [
    { id: 1, name: 'Apples' },
    { id: 2, name: 'Cola' },
    { id: 3, name: 'Bananas' },
    { id: 4, name: 'Spaghetti' },
    { id: 5, name: 'Bread' },
    { id: 6, name: 'Butter' },
    { id: 7, name: 'Milk' },
    { id: 8, name: 'Chilli' },
    { id: 9, name: 'Beef' },
    { id: 10, name: 'Chicken' },
    { id: 11, name: 'Eggs' },
    { id: 12, name: 'Cheese' },
    { id: 13, name: 'Potatoes' },
    { id: 14, name: 'Onions' },
    { id: 15, name: 'Tomatoes' },
    { id: 16, name: 'Preworkout' },
    { id: 17, name: 'Monster' },
    { id: 18, name: 'Beer' },
];

export default initialItems;