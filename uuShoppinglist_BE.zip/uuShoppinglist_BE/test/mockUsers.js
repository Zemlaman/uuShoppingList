const mockUsers = [
    {
      id: 12-34-567-8,
      name: "Matt",
      shopping_lists: [1],
    },
    {
      id: 32-34-567-8,
      name: "Jacob",
      shopping_lists: [1],
    },
    {
      id: 90-34-567-8,
      name: "Oliver",
      shopping_lists: [2],
    },
    {
      id: 56-67-789-0,
      name: "Robin",
      shopping_lists: [2],
    },
  ];
  
  module.exports = mockUsers;