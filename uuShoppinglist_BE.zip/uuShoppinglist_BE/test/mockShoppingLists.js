const mockShoppingLIsts = [
    {
      id: 1,
      name: '10.4.98',
      itemsList: [1, 2, 3, 4, 5],
      members: [
        { id: 56-67-789-0, name: 'Oliver' },
        { id: 90-34-567-8, name: 'Jacob' },
      ],
      archived: false,
      ownerId: 12-34-567-8,
    },
    {
      id: 2,
      name: 'Party',
      itemsList: [6, 7, 8, 9, 10],
      members: [
        { id: 56-67-789-0, name: 'Robin' },
        { id: 90-34-567-8, name: 'Oliver' },
      ],
      archived: false,
      ownerId: 12-34-567-8,
    },
    {
      id: 3,
      name: 'Christmas',
      itemsList: [11, 12, 13, 14, 15],
      members: [
        { id: 56-67-789-0, name: 'John' },
        { id: 90-34-567-8, name: 'Stefan' },
      ],
      archived: false,
      ownerId: 32-34-567-8,
    },
    {
      id: 4,
      name: 'Weekend',
      itemsList: [16, 17, 18],
      members: [
        { id: 56-67-789-0, name: 'Robin' },
        { id: 90-34-567-8, name: 'Boris' },
      ],
      archived: true,
      ownerId: 12-34-567-8,
    },
    {
        id: 5,
        name: 'New years eve',
        itemsList: [1, 3, 6, 9, 12, 15, 18],
        members: [
          { id: 90-34-567-8, name: 'Vojta' },
          { id: 56-67-789-0, name: 'Robin' },
        ],
        archived: true,
        ownerId: 32-34-567-8,
      }
  ];
  